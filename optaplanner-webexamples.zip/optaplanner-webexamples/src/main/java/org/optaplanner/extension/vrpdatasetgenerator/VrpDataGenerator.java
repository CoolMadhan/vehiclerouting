package org.optaplanner.extension.vrpdatasetgenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.optaplanner.examples.common.app.LoggingMain;
import org.optaplanner.examples.vehiclerouting.domain.location.Location;
import org.optaplanner.examples.vehiclerouting.domain.location.RoadLocation;

import com.graphhopper.GHRequest;
import com.graphhopper.GHResponse;
import com.graphhopper.reader.osm.GraphHopperOSM;
import com.graphhopper.routing.util.EncodingManager;

@ApplicationScoped
public class VrpDataGenerator extends LoggingMain {

    private GraphHopperOSM graphHopper;

    private static final int CAPACITY = 7;
    
    public static void main(String[] s) throws Exception {
       new VrpDataGenerator().loadMasterData("08:30", "Pick");
    }

    private int totalCustomerSize = 0;

    private Map<String, List<Location>> rosteredData = new HashMap<String, List<Location>>();

    public synchronized void loadMasterData(String shiftTime, String shiftType) throws Exception {
        String osmPath = "D://india-latest.osm.pbf";

        if (!new File(osmPath).exists()) {
            throw new IllegalStateException("The osmPath (" + osmPath + ") does not exist.\n"
                    + "Download the osm file from http://download.geofabrik.de/ first.");
        }
        graphHopper = (GraphHopperOSM) new GraphHopperOSM().forServer();
        graphHopper.setOSMFile(osmPath);
        graphHopper.setGraphHopperLocation("D:\\optaplanner-webexamples\\local\\graphHopper\\INDIA");
        graphHopper.setEncodingManager(new EncodingManager("car"));
        logger.info("graphHopper loading...");
        graphHopper.importOrLoad();
        logger.info("graphHopper loaded.");

        FileInputStream excelFile = new FileInputStream(new File(
                "D:\\optaplanner-webexamples\\src\\main\\resources\\org\\optaplanner\\webexamples\\masterdata\\Master Data.xlsx"));

        Workbook workbook = new XSSFWorkbook(excelFile);
        Sheet datatypeSheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = datatypeSheet.iterator();
        long id = 0;
        totalCustomerSize = 0;
        while (iterator.hasNext()) {
            Row currentRow = iterator.next();
            addToMap(currentRow, id);
            id++;
            totalCustomerSize++;
        }
        System.out.println("addedto map completed");
        // generateVrp("09:30_Pick");
        generateVrp(shiftTime, shiftType);
    }

    private void addToMap(Row currentRow, long id) {

        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm");
        String formattedTime = " ";
        // Dates count as numeric and must be handled separately
        if (DateUtil.isCellDateFormatted(currentRow.getCell(1))) {
            formattedTime = timeFormat.format(currentRow.getCell(1).getDateCellValue());
        }
        String key = formattedTime + "_" + currentRow.getCell(2).getStringCellValue();
        Location location = new RoadLocation();
        location.setId(id);
        location.setCustomerId(currentRow.getCell(3).getNumericCellValue());
        location.setGender(currentRow.getCell(4).getStringCellValue());
        location.setLocation(currentRow.getCell(5).getStringCellValue());
        location.setLatitude(currentRow.getCell(6).getNumericCellValue());
        location.setLongitude(currentRow.getCell(7).getNumericCellValue());
        if (rosteredData.containsKey(key)) {
            List<Location> locationList = rosteredData.get(key);
            locationList.add(location);
            rosteredData.put(key, locationList);
        } else {
            Location officeLocation = new RoadLocation();
            officeLocation.setId(Long.valueOf(0));
            officeLocation.setCustomerId(20000000);
            officeLocation.setGender("Male");
            officeLocation.setLocation(
                    "Ramanujan IT City Rajiv Gandhi Salai (OMR), Taramani, Chennai - 600 113, Tamil Nadu, India");
            officeLocation.setLatitude(12.990833);
            officeLocation.setLongitude(80.246944);
            List<Location> locationList = new ArrayList<>();
            locationList.add(officeLocation);
            locationList.add(location);
            rosteredData.put(key, locationList);
        }

    }

    public void generateVrp(String shiftTime, String shiftType) {
        System.out.println("started generate VRP");
        File vrpOutputFile = createVrpOutputFile();
        String key = shiftTime + "_" + shiftType;
        List<Location> locationList = rosteredData.get(key);
        int locationListSize = locationList != null ? locationList.size() : 0;

        BufferedWriter vrpWriter = null;
        try {
            vrpWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(vrpOutputFile), "UTF-8"));
            vrpWriter = writeHeaders(vrpWriter, locationListSize);
            writeNodeCoordSection(vrpWriter, locationList);
            writeEdgeWeightSection(vrpWriter, locationList);
            writeCustomerSection(vrpWriter, locationList);
            writeDepotSection(vrpWriter, locationList);
        } catch (IOException e) {
            throw new IllegalArgumentException(
                    "Could not read the locationFile  or write the vrpOutputFile (" + vrpOutputFile.getName() + ").",
                    e);
        } finally {
            IOUtils.closeQuietly(vrpWriter);
        }
        logger.info("Generated: {}", vrpOutputFile);
    }

    private File createVrpOutputFile() {
        int numberOfVehicle = (totalCustomerSize / CAPACITY) + 15;
        String fileName = "D:\\\\optaplanner-webexamples\\\\src\\\\main\\\\resources\\\\org\\\\optaplanner\\\\webexamples\\\\vehiclerouting\\\\masterdata.csv-road-km-n"
                + totalCustomerSize + "-k" + numberOfVehicle + ".vrp";
        File vrpOutputFile = new File(fileName);
        if (!vrpOutputFile.getParentFile().exists()) {
            throw new IllegalArgumentException(
                    "The vrpOutputFile parent directory (" + vrpOutputFile.getParentFile() + ") does not exist.");
        }
        return vrpOutputFile;
    }

    private BufferedWriter writeHeaders(BufferedWriter vrpWriter, int locationListSize) throws IOException {
        vrpWriter.write("NAME: masterdata.csv-road-km-n113-k25.vrp \n");
        vrpWriter.write("TYPE: CVRP\n");
        vrpWriter.write("DIMENSION: " + locationListSize + "\n");
        vrpWriter.write("EDGE_WEIGHT_TYPE: EXPLICIT\n");
        vrpWriter.write("EDGE_WEIGHT_FORMAT: FULL_MATRIX\n");
        vrpWriter.write("EDGE_WEIGHT_UNIT_OF_MEASUREMENT: km\n");
        vrpWriter.write("CAPACITY: " + CAPACITY + "\n");
        return vrpWriter;
    }

    private void writeNodeCoordSection(BufferedWriter vrpWriter, List<Location> locationList) throws IOException {
        vrpWriter.write("NODE_COORD_SECTION\n");
        for (Location location : locationList) {
            vrpWriter.write(location.getId() + " " + location.getLatitude() + " " + location.getLongitude() + " "
                    + location.getCustomerId() + " "
                    + (location.getLocation() != null ? " " + location.getLocation().replaceAll(" ", "_") : "")
                    + (location.getCustomerName() != null ? " " + location.getCustomerName().replaceAll(" ", "_") : "")
                    + (location.getGender() != null ? " " + location.getGender().replaceAll(" ", "_") : "") + "\n");
        }
    }

    private void writeEdgeWeightSection(BufferedWriter vrpWriter, List<Location> locationList) throws IOException {
        DecimalFormat distanceFormat = new DecimalFormat("0.000");
        vrpWriter.write("EDGE_WEIGHT_SECTION\n");
        System.out.println("locationList Size : " + locationList.size());
        for (Location fromLocation : locationList) {
            for (Location toLocation : locationList) {
                double distance;
                if (fromLocation == toLocation) {
                    distance = 0.0;
                } else {
                    // System.out.println(fromLocation +" : "+toLocation);
                    GHResponse response = fetchGhResponse(fromLocation, toLocation,
                            GenerationDistanceType.ROAD_DISTANCE_KM);
                    distance = GenerationDistanceType.ROAD_DISTANCE_KM.extractDistance(response.getBest());
                    /*
                     * if (distance == 0.0) { throw new
                     * IllegalArgumentException("The fromLocation (" + fromLocation +
                     * ") and toLocation (" + toLocation + ") have a zero distance."); }
                     */
                }
                vrpWriter.write(distanceFormat.format(distance) + " ");
            }
            vrpWriter.write("\n");
            logger.info("All distances calculated for location ({}).", fromLocation);
        }
    }

    private GHResponse fetchGhResponse(Location fromLocation, Location toLocation,
            GenerationDistanceType distanceType) {
        GHRequest request = new GHRequest(fromLocation.getLatitude(), fromLocation.getLongitude(),
                toLocation.getLatitude(), toLocation.getLongitude()).setWeighting("fastest").setVehicle("car");
        // System.out.println(toLocation.getLatitude()+" "+ toLocation.getLongitude());
        GHResponse response = graphHopper.route(request);
        if (response.hasErrors()) {
            throw new IllegalStateException(
                    "GraphHopper gave " + response.getErrors().size() + " errors. First error chained.",
                    response.getErrors().get(0));
        }
        return response;
    }

    private void writeCustomerSection(BufferedWriter vrpWriter, List<Location> locationList) throws IOException {
        vrpWriter.append("DEMAND_SECTION\n");
        boolean depotDemand = true;
        for (Location location : locationList) {
            String line = null;
            if (depotDemand) {
                depotDemand = false;
                line = location.getId() + " 0";
            } else {
                line = location.getId() + " 1";
            }
            vrpWriter.append(line).append("\n");
        }
    }

    private void writeDepotSection(BufferedWriter vrpWriter, List<Location> locationList) throws IOException {
        int depotListSize = 1;
        vrpWriter.append("DEPOT_SECTION\n");
        for (int i = 0; i < depotListSize; i++) {
            Location location = locationList.get(i);
            vrpWriter.append(Long.toString(location.getId())).append("\n");
        }
        vrpWriter.append("-1\n");
        vrpWriter.append("EOF\n");
    }
}
