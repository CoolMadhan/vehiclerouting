package org.optaplanner.extension.vrpdatasetgenerator;

import java.util.Date;

public class CustomerData {
    private Date shiftDate;
    private String shiftTime;
    private String shiftType;
    private double empCode;
    private String address;
    private double latitude;
    private double longitude;
    private String gender;
    private String empName;
    
    public String getAddress() {
        return address;
    }
    
    public double getEmpCode() {
        return empCode;
    }
    
    public String getEmpName() {
        return empName;
    }
    
    public String getGender() {
        return gender;
    }
    
    public double getLatitude() {
        return latitude;
    }
    
    public double getLongitude() {
        return longitude;
    }
    
    public Date getShiftDate() {
        return shiftDate;
    }
    
    public String getShiftTime() {
        return shiftTime;
    }
    
    public String getShiftType() {
        return shiftType;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public void setEmpCode(double empCode) {
        this.empCode = empCode;
    }
    
    public void setEmpName(String empName) {
        this.empName = empName;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    public void setShiftDate(Date shiftDate) {
        this.shiftDate = shiftDate;
    }
    
    public void setShiftTime(String shiftTime) {
        this.shiftTime = shiftTime;
    }
    
    public void setShiftType(String shiftType) {
        this.shiftType = shiftType;
    }
}
