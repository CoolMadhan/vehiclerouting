/*
 * Copyright 2015 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.webexamples.vehiclerouting.rest.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class JsonVehicleRoute {
    
    protected String depotLocationName;
    protected double depotLatitude;
    protected double depotLongitude;
    
    protected String hexColor;
    protected int capacity;
    protected int demandTotal;
    protected int routeNumber;
    public double totalDistance;
    public double totalDuration;
    
    protected List<JsonCustomer> customerList;
    
    public int getCapacity() {
        return capacity;
    }
    
    public List<JsonCustomer> getCustomerList() {
        return customerList;
    }
    
    public int getDemandTotal() {
        return demandTotal;
    }
    
    public double getDepotLatitude() {
        return depotLatitude;
    }
    
    public String getDepotLocationName() {
        return depotLocationName;
    }
    
    public double getDepotLongitude() {
        return depotLongitude;
    }
    
    public String getHexColor() {
        return hexColor;
    }
    
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    public void setCustomerList(List<JsonCustomer> customerList) {
        this.customerList = customerList;
    }
    
    public void setDemandTotal(int demandTotal) {
        this.demandTotal = demandTotal;
    }
    
    public void setDepotLatitude(double depotLatitude) {
        this.depotLatitude = depotLatitude;
    }
    
    public void setDepotLocationName(String depotLocationName) {
        this.depotLocationName = depotLocationName;
    }
    
    public void setDepotLongitude(double depotLongitude) {
        this.depotLongitude = depotLongitude;
    }
    
    public void setHexColor(String hexColor) {
        this.hexColor = hexColor;
    }

    public int getRouteNumber() {
        return routeNumber;
    }

    public void setRouteNumber(int routeNumber) {
        this.routeNumber = routeNumber;
    }

    public double getTotalDistance() {
        return totalDistance;
    }

    public void setTotalDistance(double totalDistance) {
        this.totalDistance = totalDistance;
    }

    public double getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(double totalDuration) {
        this.totalDuration = totalDuration;
    }
    
}
