package org.optaplanner.constants;

public class IConstants {
    public static final String DIRNAME = "resources";
}
